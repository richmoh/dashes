module.exports = require('./lib/pusher');
